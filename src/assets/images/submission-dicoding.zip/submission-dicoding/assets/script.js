const nav = document.querySelector(".nav-list");
const hamburger = document.querySelector(".hamburger");
const close = document.querySelector(".close");
const openAside = document.querySelector(".open-aside");
const asideContainer = document.querySelector(".aside-container");
const closeAside = document.querySelector(".close-aside");
const header = document.querySelector(".header");
const btnContact = document.querySelector("#contactMe");
const followIg = document.querySelector("#followIg");
btnContact.addEventListener("click", () => {
  window.location.href = "https://wa.me/6289630289268";
});
followIg.addEventListener("click", () => {
  window.location.href = "https://www.instagram.com/abdij06/";
});
window.addEventListener("scroll", () => {
  if (window.scrollY > 40) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
});
hamburger.addEventListener("click", () => {
  nav.classList.add("active");
});

close.addEventListener("click", () => {
  nav.classList.remove("active");
});

openAside.addEventListener("click", () => {
  asideContainer.classList.toggle("active");

  if (asideContainer.classList.contains("active")) {
    openAside.style.display = "none";
  }
});

closeAside.addEventListener("click", () => {
  asideContainer.classList.remove("active");
  openAside.style.display = "block";
});
